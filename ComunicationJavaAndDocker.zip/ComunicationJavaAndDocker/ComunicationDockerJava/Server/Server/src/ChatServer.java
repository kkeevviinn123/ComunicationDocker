import java.io.*; // Importações para operações de entrada e saída
import java.net.*; // Importações para funcionalidades de rede, como Socket
import java.util.*; // Importações para estruturas de dados, como List e ArrayList

// Classe principal que representa o servidor de chat
public class ChatServer {
    private int serverPort; // Porta em que o servidor vai escutar
    private List<ClientHandler> clients = new ArrayList<>(); // Lista de handlers para os clientes conectados
    private int nextClientId = 1; // id para o próximo cliente que se conectar

    // Construtor que inicializa o servidor com a porta especificad
    public ChatServer(int serverPort) {
        this.serverPort = serverPort;
    }

    // Método para iniciar o servidor
    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(serverPort)) {
            System.out.println("Servidor em execução.");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Novo cliente conectado.");

                ClientHandler clientHandler = new ClientHandler(clientSocket, this, nextClientId++); // Cria um handler
                                                                                                     // para o cliente
                clients.add(clientHandler); // Adiciona o handler à lista de clientes
                clientHandler.start(); // Inicia a thread para tratar as mensagens do cliente
            }
        } catch (IOException e) {
            e.printStackTrace(); // Trata exceções de entrada/saída e imprime o erro
        }
    }

    // Método para enviar uma mensagem para todos os clientes conectados
    public void broadcastMessage(String message, ClientHandler sender) {
        String formattedMessage;
        if (sender != null) {
            formattedMessage = sender.getClientName() + ": " + message; // Adiciona o nome do remetente à mensagem
        } else {
            formattedMessage = message; // Mensagem enviada pelo servidor (sem remetente) que seria a public
        }

        for (ClientHandler client : clients) {
            if (sender != null && client.getClientId() == sender.getClientId()) {
                continue; // Não envia a mensagem de volta para o remetente
            }
            client.sendMessage(formattedMessage); // Envia a mensagem formatada para todos os clientes conectados
        }
    }

    // Método para enviar uma mensagem privada para um cliente específico
    public void sendPrivateMessage(int clientId, String message, ClientHandler sender) {
        boolean recipientFound = false; // Indica se o destinatário foi encontrado na lista de clientes

        for (ClientHandler client : clients) {
            if (client.getClientId() == clientId) {
                client.sendMessage("[Mensagem privada de " + sender.getClientName() + "]: " + message);
                recipientFound = true; // Marca que o destinatário foi encontrado
                break;
            }
        }

        if (!recipientFound) {
            sender.sendMessage("Cliente não encontrado ou indisponível");
        }
    }

    // Método para remover um cliente da lista de clientes conectados
    public void removeClient(ClientHandler client) {
        clients.remove(client);
        broadcastMessage(client.getClientName() + " saiu do chat.", null);
    }

    // Método para enviar a lista de clientes ativos para um cliente específico
    public void sendActiveClientsList(ClientHandler client) {
        StringBuilder sb = new StringBuilder("Clientes conectados:\n");
        for (ClientHandler c : clients) {
            sb.append("- ").append(c.getClientId()).append(" - ").append(c.getClientName()).append("\n"); // Constrói a
                                                                                                          // lista dos
                                                                                                          // conectados
        }
        client.sendMessage(sb.toString()); // Envia a lista de clientes ativos para o cliente especificado
    }

    public void processPrivateMessage(String recipientInfo, ClientHandler sender) {
        String[] parts = recipientInfo.split(" ", 2); // Divide a informação do destinatário em duas partes
        if (parts.length >= 2) {
            String[] recipientParts = parts[0].split(":"); // Divide a parte do destinatário por ":"
            if (recipientParts.length == 2) {
                try {
                    int recipientId = Integer.parseInt(recipientParts[0]); // Obtém o ID do destinatário
                    String recipientName = recipientParts[1]; // Obtém o nome do destinatário
                    String msgContent = parts[1]; // Obtém o conteúdo da mensagem
                    sendPrivateMessage(recipientId, msgContent, sender); // Processa e envia a mensagem privada
                } catch (NumberFormatException e) {
                    sender.sendMessage("Uso: /pv <id>:<nome> <mensagem>");
                }
            } else {
                sender.sendMessage("Uso: /pv <id>:<nome> <mensagem>");
            }
        } else {
            sender.sendMessage("Uso: /pv <id>:<nome> <mensagem>");
        }
    }

    // Classe interna que representa um handler para cada cliente conectado (thread
    // separada para cada cliente)
    private class ClientHandler extends Thread {
        private int clientId;
        private Socket clientSocket;
        private BufferedReader in; // Para leitura de dados do cliente
        private PrintWriter out; // Para escrita de dados para o cliente
        private ChatServer server; // Referência ao servidor
        private String clientName;

        // Construtor que inicializa o handler do cliente
        public ClientHandler(Socket socket, ChatServer server, int clientId) {
            this.clientSocket = socket; // Inicializa o socket do cliente
            this.server = server; // Referência ao servidor
            this.clientId = clientId; // Inicializa o ID do cliente
        }

        // Método de execução da thread para tratar mensagens do cliente
        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); // Para ler mensagens do
                                                                                               // cliente
                out = new PrintWriter(clientSocket.getOutputStream(), true); // Para enviar mensagens para o cliente

                clientName = in.readLine(); // Lê o nome do cliente
                System.out.println(clientId + " - " + clientName + " entrou no chat!");

                server.sendActiveClientsList(this); // Envia a lista de clientes ativos para o cliente recém-conectado
                server.broadcastMessage(clientName + " entrou no chat.", this);
                String message;
                while ((message = in.readLine()) != null) {
                    if (message.startsWith("/pv")) {
                        String[] parts = message.split(" ", 2);
                        if (parts.length >= 2) {
                            String recipientInfo = parts[1]; // Remove "/pv " do input
                            server.processPrivateMessage(recipientInfo, this); // Processa mensagem privada
                        } else {
                            sendMessage("Uso: /pv <id>:<nome> <mensagem>");
                        }
                    } else if (message.equalsIgnoreCase("sair")) {
                        break;
                    } else {
                        server.broadcastMessage(message, this); // Transmite mensagem para todos os clientes
                    }
                }
            } catch (IOException e) {
                System.out.println("Erro ao tratar o cliente: " + e.getMessage());
            } finally {
                // Remove o cliente da lista de clientes do servidor
                server.removeClient(this);
                try {
                    clientSocket.close(); // Fecha o socket do cliente
                } catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println(clientName + " desconectado");
                server.broadcastMessage(clientName + " saiu do chat.", null);
            }
        }

        // Método para enviar mensagem para o cliente
        public void sendMessage(String message) {
            out.println(message); // Envia mensagem para o cliente
        }

        // Métodos para obter informações do cliente
        public int getClientId() {
            return clientId; // Retorna o ID do cliente
        }

        public String getClientName() {
            return clientName; // Retorna o nome do cliente
        }
    }

    // Método principal para iniciar o servidor na porta especificada
    public static void main(String[] args) {
        ChatServer server = new ChatServer(8000); // Cria o servidor na porta 8000
        server.start(); // Inicia o servidor
    }
}
