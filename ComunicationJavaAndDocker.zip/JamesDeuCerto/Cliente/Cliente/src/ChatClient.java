import java.io.*; // Para operações de entrada e saída
import java.net.*; // Para funcionalidades de rede, como Socket
import java.util.Scanner; // Para ler entrada do usuário

public class ChatClient {

    private String serverAddress; // Endereço IP do servidor
    private int serverPort; // Porta do servidor
    private String clientName; // Nome do cliente

    private Socket socket; // Socket para comunicação com o servidor
    private BufferedReader serverIn; // Para leitura de dados do servidor
    private PrintWriter serverOut; // Para escrita de dados para o servidor

    // Construtor da classe ChatClient
    public ChatClient(String serverAddress, int serverPort, String clientName) {
        this.serverAddress = serverAddress;
        this.serverPort = serverPort;
        this.clientName = clientName;
    }

    // Método para iniciar a execução do cliente
    public void start() {
        try {
            // Conecta ao servidor usando o endereço e a porta fornecidos
            socket = new Socket(serverAddress, serverPort);
            serverIn = new BufferedReader(new InputStreamReader(socket.getInputStream())); // Para receber mensagens do
                                                                                           // servidor
            serverOut = new PrintWriter(socket.getOutputStream(), true); // Para enviar mensagens para o servidor

            System.out.println("Tentando conectar ao servidor " + serverAddress + " na porta " + serverPort);
            // Envia o nome do cliente para o servidor
            serverOut.println(clientName);

            // Inicia uma thread separada para receber mensagens do servidor
            new Thread(() -> {
                try {
                    String serverResponse;
                    // Enquanto houver mensagens do servidor para ler
                    while ((serverResponse = serverIn.readLine()) != null) {
                        System.out.println(serverResponse); // Exibe as mensagens recebidas do servidor na tela
                                                            // docliente
                    }
                } catch (IOException e) {
                    e.printStackTrace(); // Exibe o errr na saída de erro padrão
                }
            }).start();

            // Lê entrada do usuário e envia mensagens para o servidor
            Scanner userInput = new Scanner(System.in);
            String userInputLine;
            while ((userInputLine = userInput.nextLine()) != null) {
                if (userInputLine.startsWith("/pv")) {
                    // Comando para mensagem privada: /pv <id>:<nome> <mensagem>
                    String[] split = userInputLine.split(" ", 2); // Divide a entrada em duas partes no primeiro espaço
                    if (split.length == 2) {
                        serverOut.println(userInputLine); // Envia a mensagem diretamente para o servidor
                    } else {
                        System.out.println("Uso incorreto do comando. Formato: /pv <id>:<nome> <mensagem>");
                    }
                } else if (userInputLine.equalsIgnoreCase("sair")) {
                    serverOut.println("sair"); // Envia comando para sair do chat para o servidor
                    break;
                } else {
                    serverOut.println(userInputLine); // Envia mensagem para o servidor
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao conectar ao servidor: " + e.getMessage()); // Exibe mensagem de erro de conexão
        } finally {
            try {
                if (socket != null) {
                    socket.close(); // Fecha o socket do cliente
                }
            } catch (IOException e) {
                e.printStackTrace(); // Exibe o erro na saída de erro padrão
            }
        }
    }

    // Método principal que cria um cliente e inicia a execução
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o IP do servidor: ");
        String serverAddress = scanner.nextLine();

        System.out.print("Digite a porta do servidor: ");
        int serverPort = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Digite seu nome: ");
        String clientName = scanner.nextLine();

        // Cria um novo cliente e inicia a comunicação com o servidor
        ChatClient client = new ChatClient(serverAddress, serverPort, clientName);
        client.start();
    }
}
